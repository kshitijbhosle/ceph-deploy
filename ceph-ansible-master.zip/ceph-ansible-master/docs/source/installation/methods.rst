Installation methods
====================

ceph-ansible can deploy Ceph either in a non-containerized context (via packages) or in a containerized context using ceph-container images.

.. toctree::
   :maxdepth: 1

   non-containerized
   containerized
