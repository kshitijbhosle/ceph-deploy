# Ansible role: ceph-rbd

Documentation is available at http://docs.ceph.com/ceph-ansible/.
